# Author: Chris Long
# This script executes the Sysinternals Autoruns CLI utility
# A CSV will be created, imported, parsed into JSON and finally logged to a
# custom Windows Event Log. The event log will be forwarded via a WEF subscription.

## Code to create the custom windows event log if it doesn't exist
$logfileExists = Get-Eventlog -list | Where-Object {$_.logdisplayname -eq "Autoruns"}
if (! $logfileExists) {
  New-EventLog -LogName Autoruns -Source AutorunsToWEF
}

## Run the CLI version of autoruns
# -nobanner    Don't output the banner (breaks CSV parsing)
# /accepteula  Automatically accept the EULA
# -a *         Record all entries
# -c           Output as CSV
# -h           Show file hashes
# -m           Hide Microsoft signed entries
# -s           Verify digital signature
# -v           Query file hashes againt Virustotal
# -vt          Accept Virustotal Terms of Service
#  *           Scan all user profiles


$autorunsCsv = "c:\Program Files\Palantir\AutorunsToWEF\AutorunsOutput.csv"

## Normally we'd add a "-Wait" flag to this Start-Process, but it seems to be
## broken when called from RunAs or Scheduled Tasks: https://goo.gl/8NcvcK
$proc = Start-Process -FilePath "c:\Program Files\Palantir\AutorunsToWEF\Autorunsc64.exe" -ArgumentList '-nobanner', '/accepteula', '-a *', '-c', '-h', '-m', '-s', '-v', '-vt', '*'  -RedirectStandardOut $autorunsCsv -WindowStyle hidden -Passthru
$proc.WaitForExit()
$autorunsArray = Import-Csv $autorunsCsv

Foreach ($item in $autorunsArray) {
  $item = $($item | ConvertTo-Json)
  Write-EventLog -LogName Autoruns -Source AutorunsToWEF -EntryType Information -EventId 1 -Message $item
}
