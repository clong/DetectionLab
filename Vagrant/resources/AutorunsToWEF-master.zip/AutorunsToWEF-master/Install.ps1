# Create Program Files directories
$autorunsDir = "C:\Program Files\Palantir\AutorunsToWEF"
If(!(test-path $autorunsDir)) {
  New-Item -ItemType Directory -Force -Path $autorunsDir
}

# Download Autorunsc64.exe if it doesn't exist
$autorunsPath = "c:\Program Files\Palantir\AutorunsToWEF\Autorunsc64.exe"
if(!(test-path $autorunsPath)) {
  Invoke-WebRequest -Uri "https://live.sysinternals.com/autorunsc64.exe" -OutFile "$autorunsPath"
}

# Put a copy of the signed AutorunsToWEF script in the Autoruns directory
copy "$PSScriptRoot\AutorunsToWEF_signed.ps1" "$autorunsDir\AutorunsToWEF.ps1"

$ST_A = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle hidden c:\PROGRA~1\Palantir\AutorunsToWEF\AutorunsToWEF.ps1"
$ST_T = New-ScheduledTaskTrigger -Daily -At 11am
$ST_P = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\SYSTEM" -RunLevel Highest -LogonType ServiceAccount
Register-ScheduledTask -TaskName "AutorunsToWEF" -Action $ST_A -Trigger $ST_T -Principal $ST_P

$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden -ExecutionTimeLimit (New-TimeSpan -Minutes 60) -RestartCount 1 -StartWhenAvailable
Set-ScheduledTask -TaskName "AutorunsToWEF" -Settings $settings
