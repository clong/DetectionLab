import xml.etree.ElementTree as ET
import os


def validate(wef_xml):
    pass


def find_all_subscriptions():
    return [f for f in os.listdir(".") if os.path.isfile(os.path.join(".", f)) and f.endswith("xml")]

##  xml2 files are identical to the xml files, but the CDATA tag is removed so that we can validate the query XML in addition to the outer XML
def find_all_subscriptions_cdata_removed():
    return [f for f in os.listdir(".") if os.path.isfile(os.path.join(".", f)) and f.endswith("xml2")]

def main():
    for sub in find_all_subscriptions():
        wef_xml = ET.parse(sub)
        validate(wef_xml)

    for sub in find_all_subscriptions_cdata_removed():
        wef_xml = ET.parse(sub)
        validate(wef_xml)

if __name__ == "__main__":
    main()
