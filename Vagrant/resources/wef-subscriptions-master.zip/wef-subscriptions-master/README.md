# WEF-Subscriptions
```
Windows Event Forwarding or WEF is a subscription-based methodology to push events of interest to a Windows Event Collector.  Subscriptions can be either source-initiated (push) or collector-initiated (pull).  Subscriptions rely on subscriber clients to have logging and WinRM turned on locally for the subscription request. In Palantir's environment with always-changing numbers of Windows systems, source-initiated subscriptions configured via GPO is the optimal model.
```

## List of WEF buckets
```
WEC-Authentication
WEC-EMET
WEC-Powershell
WEC-Process-Execution
WEC-Services
WEC-WMI
WEC-Code-Integrity
```
```
WEC2-Group-Policy-Errors
WEC2-Applocker
WEC2-Windows-Defender
WEC2-File-System
WEC2-Application-Crashes
WEC2-Registry
WEC2-Task-Scheduler
```
```
WEC3-Account-Management
WEC3-Drivers
WEC3-Windows-Diagnostics
WEC3-Smart-Card
WEC3-USB
WEC3-Print
WEC3-Firewall
```
```
WEC4-Wireless
WEC4-Shares
WEC4-Bits-Client
WEC4-Windows-Updates
WEC4-Hotpatching-Errors
WEC4-DNS
WEC4-System-Time-Change
```
```
WEC5-Certificate-Authority
WEC5-Crypto-API
WEC5-Log-Deletion-Security
WEC5-Log-Deletion-System
WEC5-MSI-Packages
```

## Windows Event Collector Utility 101

Create a subscription or all the subscriptions
```
wecutil cs subscription.xml

C:\subscription-dir> for /r %i in (*.xml) do wecutil cs %i
```

Delete a subscription or all the subscriptions
WARNING: You're better off disabling the subscriptions first for server/eventvwr stability.
```
wecutil ds subscriptionid

C:\subscription-dir> for /r %i in (*.xml) do wecutil ds %~ni
```

See XML details and subscribers
```
wecutil gs subscriptionid
```