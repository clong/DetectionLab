# windows-event-channels
Custom windows event channels used in conjunction with WEF servers.

List of Windows Event Channels:
```
WEC-Powershell
WEC-WMI
WEC-EMET
WEC-Authentication
WEC-Services
WEC-Process-Execution
WEC-Code-Integrity
WEC2-Registry
WEC2-File-System
WEC2-Applocker
WEC2-Task-Scheduler
WEC2-Application-Crashes
WEC2-Windows-Defender
WEC2-Group-Policy-Errors
WEC3-Drivers
WEC3-Account-Management
WEC3-Windows-Diagnostics
WEC3-Smart-Card
WEC3-USB
WEC3-Print
WEC3-Firewall
WEC4-Wireless
WEC4-Shares
WEC4-Bits-Client
WEC4-Windows-Update
WEC4-Hotpatching-Errors
WEC4-DNS
WEC4-System-Time-Change
WEC5-Operating-System
WEC5-Certificate-Authority
WEC5-Crypto-API
WEC5-MSI-Packages
WEC5-Log-Deletion-Security
WEC5-Log-Deletion-System
WEC5-Autoruns
```

## Pre-Requisites:
You will need the following software to build the DLL:
- Windows 8.1 SDK
- Windows Workstation

## Editing:
Launch the Manifest Generator
```
“C:\Program Files (x86)\Windows Kits\8.1\bin\x64\ecmangen.exe”
```

Load the CustomEventChannels.man file from this repo.

Make any changes to the file. Ensure the following settings are observed:
- All channels are marked as Operational and Enabled.
- No more than 7 channels are added to each provider.
- Channels following the naming scheme (WEC#-Name)
- Symbols use underscores and not hyphens.

![mc.png](img/mangen.png)

## Compiling:
To compile, perform the following from a cmd.exe shell:
```
"C:\Program Files (x86)\Windows Kits\8.1\bin\x64\mc.exe" CustomEventChannels.man
"C:\Program Files (x86)\Windows Kits\8.1\bin\x64\mc.exe" -css CustomEventChannels.DummyEvent CustomEventChannels.man
"C:\Program Files (x86)\Windows Kits\8.1\bin\x64\rc.exe" CustomEventChannels.rc
"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /win32res:CustomEventChannels.res /unsafe /target:library /out:CustomEventChannels.dll C:CustomEventChannels.cs

```

## Deployment:

For each WEF server you need to deploy this to, perform the following:

1) Disable the Windows Event Collector Service:

```
net stop Wecsvc
```

2) Disable all current WEF subscriptions. More details how to do that here: https://wiki.yojoe.local/display/INFOSEC/Windows+Event+Forwarding


3) Unload the current Event Channel file:
```
wevtutil um C:\windows\system32\CustomEventChannels.man
```

4) Copy (and replace) the following files to each WEF server under C:\Windows\system32:
```
CustomEventChannels.dll
CustomEventChannels.man
```

5) Load the new Event Channel file:
```
wevtutil im C:\windows\system32\CustomEventChannels.man
```

6) Resize the log files:
```
wevtutil sl <logname> /ms:4294967296
```

7) Re-enable the WEF subscriptions.

8) Re-enable the Windows Event Collector service
